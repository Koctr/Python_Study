# -*- encoding:utf-8 -*-
# Author: Koctr

import os

# 最大登录次数
MAX_LOGIN_TIMES = 3
# 最大密码错误次数
MAX_PASSWORD_ERRORS = 3
# 登录失败次数
login_failure_times = 0
while login_failure_times < MAX_LOGIN_TIMES:
    username = input("请输入用户名：")
    password = input("请输入密码：")
    with open("locked_users", "r+", encoding="utf-8") as locked_users_file:
        user_locked = False
        for user_info in locked_users_file:
            if username in user_info:
                print("用户已被锁定，无法登录")
                login_failure_times += 1
                user_locked = True
                break
        # 用户未锁定才判断用户是否存在及用户密码是否正确
        if not user_locked:
            # 标示用户是否存在
            user_exist = False
            with open("users_info", "r", encoding="utf-8") as users_info_file, \
                    open("users_info.bak", "w", encoding="utf-8") as users_info_file_bak:
                for line in users_info_file:
                    user_info = eval(line)
                    if username in user_info:
                        user_exist = True
                        if user_info[username][0] != password:
                            login_failure_times += 1
                            print("用户名或密码错误，你还有%s次登录机会" % (MAX_LOGIN_TIMES - login_failure_times))
                            # 用户密码错误次数
                            user_info[username][1] += 1
                            if user_info[username][1] >= MAX_PASSWORD_ERRORS:
                                locked_users_file.writelines(username + "\n")
                            users_info_file_bak.writelines(str(user_info) + "\n")
                        else:
                            print("恭喜你，登录成功")
                            exit()
                    else:
                        users_info_file_bak.writelines(line)
            os.remove("users_info")
            os.rename("users_info.bak", "users_info")
            if not user_exist:
                login_failure_times += 1
                print("用户名不存在，你还有%s次登录机会" % (MAX_LOGIN_TIMES - login_failure_times))
else:
    print("登录失败3次，程序退出")
