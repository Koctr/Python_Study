博客地址：http://www.cnblogs.com/koctr/
学习笔记一——学习笔记八是第一模块的学习笔记
python学习知识库，是编写程序过程中的问题及解决办法，
地址：http://www.cnblogs.com/koctr/p/7257561.html

程序实现过程：
建立项目tasks，在tasks下建立目录module1，表示是模块一的程序，建立mock_login目录，表示是模拟用户登录程序
1. 工资管理系统
   包含以下文件：
   readme.txt是程序说明。
   流程图_工资管理.png是程序流程图。
   manage_salary.py是程序文件，在Pycharm中运行。
   info保存员工信息

   程序按照流程图顺序执行，在Pycharm中运行程序